const objetos = [objeto7, objeto8, objeto9];
fotosExposicion(objetos);