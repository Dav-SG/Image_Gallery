/**
 * Se declara un array de objetos los cuales fueron declarados en main.js y se le envia como paramentro a
 * la función fotosExpocision
 */

const objetos = [];
fotosExposicion(objetos);