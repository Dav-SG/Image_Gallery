const objetos = [objeto1, objeto2, objeto3];
fotosExposicion(objetos);