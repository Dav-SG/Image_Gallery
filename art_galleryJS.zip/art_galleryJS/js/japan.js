const objetos = [objeto4, objeto5, objeto6];
fotosExposicion(objetos);